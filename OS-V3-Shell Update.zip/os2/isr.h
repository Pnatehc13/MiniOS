#ifndef ISR_H
#define ISR_H

#include "types.h"

typedef struct registers {
    uint32_t ds, es, fs, gs;
    uint32_t edi, esi, ebp, esp, ebx, edx, ecx, eax;
    uint32_t int_no, err_code;
    uint32_t eip, cs, eflags, useresp, ss;
} registers_t;

void isr_handler_c(registers_t* regs);
void *memset(void *dest, int val, size_t len);
void *memcpy(void *dest, const void *src, size_t n);
int strcmp(const char* s1, const char* s2);
int atoi(const char* str);
#endif
