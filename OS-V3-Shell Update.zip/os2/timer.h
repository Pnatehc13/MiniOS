#ifndef TIMER_H
#define TIMER_H

#include "isr.h"

void init_timer(uint32_t frequency);
void sleep_s(uint32_t seconds);
#endif