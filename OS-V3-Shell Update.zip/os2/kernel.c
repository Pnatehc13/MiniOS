
#include "types.h"
#include "terminal.h"
#include "gdt.h"
#include "shell.h"
#include "idt.h"
#include "irq.h"
#include "ports.h"
#include "timer.h"
#include "keyboard.h"
/* Check if the compiler thinks you are targeting the wrong operating system. */
#if defined(_linux_)
#error "You are not using a cross-compiler, you will most certainly run into trouble"
#endif

/* This tutorial will only work for the 32-bit ix86 targets. */
#if !defined(i386)
#error "This tutorial needs to be compiled with a ix86-elf compiler"
#endif

void keyboard_isr_c(registers_t* regs);

void kernel_main(void) 
{
    terminal_initialize();
    terminal_writestring("Kernel initialized successfully.\n");

  
    gdt_init();

    init_idt();
    pic_remap();
    init_timer(50); // 50 Hz timer
    // Unmask IRQ1 (keyboard)
    uint8_t mask = inb(0x21);
    mask &= ~(1 << 0);
    mask &= ~(1 << 1);
    outb(0x21, mask);

    register_interrupt_handler(0x21, keyboard_isr_c);

    asm volatile("sti");
    terminal_writestring("Interrupts enabled.\n");
    shell_init();
	while(1) {
        if (shell_is_command_ready()) {
            shell_run_command_from_buffer();
            shell_print_prompt();
        }
        asm volatile("hlt");
    }
}
