#ifndef SHELL_H
#define SHELL_H

#include "types.h" // For bool

void shell_init(void);
void shell_handle_key(char c);

// --- ADD/UPDATE THESE ---
void shell_run_command_from_buffer(void);
void shell_print_prompt(void);
bool shell_is_command_ready(void);
// --- END ---

#endif