    #include "types.h"
    #include "irq.h"
    #include "terminal.h"
    #include "isr.h"
    #define MAX_IRQS 256
    void (*interrupt_handlers[MAX_IRQS])(registers_t*);

    void register_interrupt_handler(uint8_t n, void (*handler)(registers_t*)) {
        interrupt_handlers[n] = handler;
    }
    // I/O port functions (you likely already have these in some util)
    static inline void outb(uint16_t port, uint8_t value) {
        asm volatile ("outb %0, %1" : : "a"(value), "Nd"(port));
    }
    static inline uint8_t inb(uint16_t port) {
        uint8_t ret;
        asm volatile ("inb %1, %0" : "=a"(ret) : "Nd"(port));
        return ret;
    }

    #define PIC1            0x20 // Master PIC
    #define PIC2            0xA0 // Slave PIC
    #define PIC1_COMMAND    PIC1
    #define PIC1_DATA       (PIC1 + 1)
    #define PIC2_COMMAND    PIC2
    #define PIC2_DATA       (PIC2 + 1)

    #define ICW1_ICW4       0x01    // ICW4 (not) needed
    #define ICW1_INIT       0x10    // Initialization required
    #define ICW4_8086       0x01    // 8086/88 mode

void pic_remap(void)
{
    // Your memset fix (this is correct, keep it)
    memset(&interrupt_handlers, 0, sizeof(void*) * MAX_IRQS);

    // REMOVE these two lines:
    // uint8_t a1 = inb(PIC1_DATA);
    // uint8_t a2 = inb(PIC2_DATA);

    // Start initialization sequence
    outb(PIC1_COMMAND, ICW1_INIT | ICW1_ICW4);
    outb(PIC2_COMMAND, ICW1_INIT | ICW1_ICW4);

    // Set vector offsets
    outb(PIC1_DATA, 0x20); // Master PIC vector offset = 0x20 (32)
    outb(PIC2_DATA, 0x28); // Slave PIC vector offset  = 0x28 (40)

    // Tell Master PIC that there’s a slave at IRQ2 (0000 0100)
    outb(PIC1_DATA, 4);
    // Tell Slave PIC its cascade identity (0000 0010)
    outb(PIC2_DATA, 2);

    // Set environment info
    outb(PIC1_DATA, ICW4_8086);
    outb(PIC2_DATA, ICW4_8086);

    // REPLACE these two lines:
    // outb(PIC1_DATA, a1);
    // outb(PIC2_DATA, a2);
    // WITH THESE:
    outb(PIC1_DATA, 0xFF); // Mask all interrupts on Master
    outb(PIC2_DATA, 0xFF); // Mask all interrupts on Slave
}

    void irq_handler_c(registers_t* regs) {
        // debug print
        

        // call user handler if installed
        if (interrupt_handlers[regs->int_no]) {
            interrupt_handlers[regs->int_no](regs);
        }

        // Send EOI
        if (regs->int_no >= 40)
            outb(0xA0, 0x20); // slave PIC
        outb(0x20, 0x20);     // master PIC
    }