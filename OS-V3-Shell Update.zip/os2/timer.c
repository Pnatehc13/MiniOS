#include "timer.h"
#include "terminal.h"
#include "irq.h"
#include "ports.h"

uint32_t tick = 0;

// This is our C-level interrupt handler
void timer_isr_c(registers_t* regs) {
    tick++;
    // For now, let's just prove it's working
    // We'll print a . in the top right corner
    terminal_putentryat('.', 0x07, 79, 0); 
}

void init_timer(uint32_t frequency) {
    // 1. Register our C handler
    register_interrupt_handler(32, timer_isr_c); // 32 is IRQ 0

    // 2. Set the PIT frequency
    uint32_t divisor = 1193180 / frequency;
    
    // Send the command byte (Set Channel 0, low/high byte access, square wave mode)
    outb(0x43, 0x36);

    // Send the frequency divisor, low byte first, then high byte
    uint8_t low  = (uint8_t)(divisor & 0xFF);
    uint8_t high = (uint8_t)((divisor >> 8) & 0xFF);
    
    outb(0x40, low);
    outb(0x40, high);
}

void sleep_s(uint32_t seconds) {
    uint32_t target_tick = tick + (seconds * 100); // Assuming 50 Hz timer
    while (tick < target_tick) {
        asm volatile("hlt"); // Halt CPU until next interrupt
    }
    
}