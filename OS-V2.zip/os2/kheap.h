#ifndef KHEAP_H
#define KHEAP_H

#include "types.h"

// Initializes the heap and bitmap
void init_kheap(void);

// Allocates one 4KB page
void* kmalloc_page(void);

// Frees one 4KB page
void kfree_page(void* ptr);
uint32_t alloc_phys_page(void);
void free_phys_page(uint32_t phys_addr);
#endif