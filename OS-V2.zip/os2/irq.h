#ifndef IRQ_H
#define IRQ_H

#include "types.h"
#include "isr.h"
// Public functions
void pic_remap(void);
void register_interrupt_handler(uint8_t n, void (*handler)(registers_t*));

#endif
