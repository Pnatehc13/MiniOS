#include "isr.h"
#include "terminal.h"

// Your helper functions
void *memset(void *dest, int val, size_t len) {
    unsigned char *ptr = (unsigned char*)dest;
    while (len-- > 0)
        *ptr++ = (unsigned char) val;
    return dest;
}

void *memcpy(void *dest, const void *src, size_t n) {
    unsigned char *d = (unsigned char*)dest;
    const unsigned char *s = (const unsigned char*)src;
    for (size_t i = 0; i < n; i++) {
        d[i] = s[i];
    }
    return dest;
}

int strcmp(const char* s1, const char* s2) {
    while (*s1 && (*s1 == *s2)) {
        s1++;
        s2++;
    }
    return *(const unsigned char*)s1 - *(const unsigned char*)s2;
}

int atoi(const char* str) {
    int result = 0;
    while (*str) {
        if (*str < '0' || *str > '9') break; // Handle non-numeric chars
        result = result * 10 + (*str - '0');
        str++;
    }
    return result;
}


// --- Main C-level Exception Handler ---
// This is the new function signature
void isr_handler_c(registers_t* regs, int_stack_frame_t* stack) {
    
    terminal_writestring("\n--- KERNEL EXCEPTION ---\n");
    terminal_writestring("Exception: ");
    
    uint8_t int_no = (uint8_t)stack->int_no; 
    
    char num_buf[4]; // Buffer for number
    num_buf[0] = '0' + (int_no / 10);
    num_buf[1] = '0' + (int_no % 10);
    num_buf[2] = '\0';
    
    terminal_writestring(num_buf);
    terminal_writestring("\nHalting system.\n");
    
    while(1);
}


// NEW FUNCTION: Converts a 32-bit int to a hex string
void int_to_hex_str(uint32_t n, char* buffer) {
    const char* hex = "0123456789ABCDEF";
    buffer[0] = '0';
    buffer[1] = 'x';
    buffer[10] = '\0'; // Null terminator

    // Start from the last character and go backwards
    for (int i = 8; i >= 1; i--) {
        // Get the last 4 bits
        uint32_t nibble = n & 0xF;
        
        // The index in the buffer is i+1
        // (i=8 -> buffer[9], i=1 -> buffer[2])
        buffer[i + 1] = hex[nibble];
        
        // Move to the next 4 bits
        n = n >> 4;
    }
}