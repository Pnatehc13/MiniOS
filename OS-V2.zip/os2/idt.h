#ifndef __IDT_H__
#define __IDT_H__
#include <stdint.h>
#include "types.h"
// IDT entry structure

struct idt_entry {
    uint16_t base_low;    // Lower 16 bits of handler function address
    uint16_t sel;         // Kernel segment selector
    uint8_t  always0;     // This must always be zero
    uint8_t  flags;       // Flags
    uint16_t base_high;   // Upper 16 bits of handler function address
} __attribute__((packed));
typedef struct idt_entry idt_entry_t;

// IDT pointer structure
struct idt_ptr {    
    uint16_t limit;   // Size of the IDT
    uint32_t base;    // Base address of the first element in the IDT
} __attribute__((packed));  
typedef struct idt_ptr idt_ptr_t;

void init_idt();
extern void idt_flush(uint32_t);
void idt_set_gate(uint8_t num, uint32_t base, uint16_t sel, uint8_t flags);

#endif // __IDT_H__
