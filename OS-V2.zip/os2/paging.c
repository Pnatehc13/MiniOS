#include "paging.h"
#include "terminal.h"
#include "isr.h"
#include "idt.h" // For idt_set_gate
#include "kheap.h" // For alloc_phys_page

// --- Assembly functions ---
extern void load_page_directory(uint32_t* page_directory);
extern void enable_paging(void);
extern void flush_tlb(void);

// --- Linker symbols ---
extern uint32_t _kernel_start;
extern uint32_t _kernel_code_end;
extern uint32_t _kernel_end;

// --- Page Directory and Page Table definitions ---
uint32_t page_directory[1024] __attribute__((aligned(4096)));

// --- Page Fault Handler (Exception 14) ---
void page_fault_handler(registers_t* regs, int_stack_frame_t* stack) {
    // This union fixes the 'strict-aliasing' warning
    union {
        uint32_t as_int;
        page_fault_code_t as_struct;
    } error;

    error.as_int = stack->err_code; // Safely copy the code

    // The CPU saves the "bad" address in a special register, CR2
    uint32_t fault_addr;
    asm volatile("mov %%cr2, %0" : "=r" (fault_addr));

    // Use our hex print function to show the address
    char addr_buffer[11];
    int_to_hex_str(fault_addr, addr_buffer);

    terminal_writestring("\n--- PAGE FAULT ---\n");
    terminal_writestring("Address: ");
    terminal_writestring(addr_buffer);
    
    terminal_writestring("\nReason: ");
    if (!error.as_struct.present) terminal_writestring("Not present ");
    if (error.as_struct.rw)       terminal_writestring("Read-only write ");
    if (error.as_struct.user)     terminal_writestring("User-mode ");
    if (error.as_struct.fetch)    terminal_writestring("Instruction fetch ");
    
    terminal_writestring("\nHalting system.\n");
    while(1); // Halt
}

// --- Paging Initialization ---
void init_paging(void) {
    // 1. Clear the directory
    memset(page_directory, 0, sizeof(uint32_t) * 1024);

    // Hard-code the first 4 page tables (for 16MB)
    // We place them right after the page directory
    uint32_t* page_table_1 = (uint32_t*)(page_directory + 1024);
    uint32_t* page_table_2 = (uint32_t*)(page_table_1 + 1024);
    uint32_t* page_table_3 = (uint32_t*)(page_table_2 + 1024);
    uint32_t* page_table_4 = (uint32_t*)(page_table_3 + 1024);

    memset(page_table_1, 0, 4096);
    memset(page_table_2, 0, 4096);
    memset(page_table_3, 0, 4096);
    memset(page_table_4, 0, 4096);

    // Get addresses from the linker
    uint32_t kernel_start_addr = (uint32_t)&_kernel_start;
    uint32_t kernel_code_end_addr = (uint32_t)&_kernel_code_end;
    uint32_t kernel_end_addr = (uint32_t)&_kernel_end;

    // Align addresses to 4KB page boundaries (always round UP)
    uint32_t kernel_code_end_page = (kernel_code_end_addr + 0xFFF) & ~0xFFF;
    uint32_t kernel_end_page = (kernel_end_addr + 0xFFF) & ~0xFFF;

    // 2. Identity-map all 16MB (4096 pages)
    for (int i = 0; i < 4096; i++) {
        uint32_t page_addr = i * 0x1000;
        uint32_t flags = 0;

        // --- THIS IS THE CRITICAL LOGIC ---
        if (page_addr < kernel_start_addr) {
            // Low memory (0MB - 2MB). User stack is here.
            flags = 0x7; // Present, R/W, USER
        
        } else if (page_addr >= kernel_start_addr && page_addr < kernel_code_end_page) {
            // Kernel .text and .rodata. User code is here.
            flags = 0x5; // Present, R/O, USER
        
        } else if (page_addr >= kernel_code_end_page && page_addr < kernel_end_page) {
            // Kernel .data and .bss (stack). KERNEL ONLY.
            flags = 0x3; // Present, R/W, KERNEL
        
        } else {
            // Memory after our kernel (up to 16MB). KERNEL ONLY.
            flags = 0x3; // Present, R/W, KERNEL
        }
        // --- END CRITICAL LOGIC ---

        // Figure out which page table this entry belongs to
        if (i < 1024)       page_table_1[i] = page_addr | flags;
        else if (i < 2048)  page_table_2[i - 1024] = page_addr | flags;
        else if (i < 3072)  page_table_3[i - 2048] = page_addr | flags;
        else                page_table_4[i - 3072] = page_addr | flags;
    }

    // 3. Put the 4 page tables into the page_directory
    page_directory[0] = (uint32_t)page_table_1 | 0x3;
    page_directory[1] = (uint32_t)page_table_2 | 0x3;
    page_directory[2] = (uint32_t)page_table_3 | 0x3;
    page_directory[3] = (uint32_t)page_table_4 | 0x3;

    // 4. Register our Page Fault handler
    idt_set_gate(14, (uint32_t)page_fault_handler, 0x08, 0x8E);
    
    // 5. Load the page directory and enable paging
    load_page_directory(page_directory);
    enable_paging();
}


// --- `map_page` and `unmap_page` functions ---

void map_page(uint32_t phys_addr, uint32_t virt_addr, uint32_t flags) {
    uint32_t dir_index = virt_addr >> 22;
    uint32_t table_index = (virt_addr >> 12) & 0x3FF;
    uint32_t* page_table;

    if (page_directory[dir_index] & 0x1) {
        // Page table exists.
        // We know it's identity-mapped in the first 16MB.
        page_table = (uint32_t*)(page_directory[dir_index] & 0xFFFFF000);
    } else {
        // Page table does not exist. We must create it.
        uint32_t new_table_phys = alloc_phys_page();
        if (!new_table_phys) {
            terminal_writestring("OUT OF MEMORY creating page table!\n");
            return;
        }
        
        // Add new table to directory
        page_directory[dir_index] = new_table_phys | 0x7; // Present, R/W, User

        // Get its virtual address (it's identity-mapped!)
        page_table = (uint32_t*)new_table_phys;
        
        // Clear the new table
        memset(page_table, 0, 4096);
    }
    
    // Add the mapping
    page_table[table_index] = phys_addr | flags;
    flush_tlb();
}

void unmap_page(uint32_t virt_addr) {
    uint32_t dir_index = virt_addr >> 22;
    // --- THIS IS THE FIX (changed table__index to table_index) ---
    uint32_t table_index = (virt_addr >> 12) & 0x3FF;

    if (page_directory[dir_index] & 0x1) {
        uint32_t* page_table = (uint32_t*)(page_directory[dir_index] & 0xFFFFF000);
        
        // Now this line is correct
        page_table[table_index] = 0x0; // Clear the entry
        flush_tlb();
    }
}