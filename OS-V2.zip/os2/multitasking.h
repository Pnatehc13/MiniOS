#ifndef MULTITASKING_H
#define MULTITASKING_H

// This function will jump to user mode.
// We'll call it from our kernel.
void jump_to_user_mode(void);

#endif