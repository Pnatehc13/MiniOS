#include "gdt.h"
#include "tss.h" // <-- ADDED

// Our GDT will have 6 entries
gdt_entry_t gdt_entries[6]; // <-- CHANGED
gdt_ptr_t   gdt_ptr;    

// This is the global TSS instance from tss.c
extern tss_entry_t tss; // <-- ADDED

void gdt_set_gate(int32_t num, uint32_t base, uint32_t limit, uint8_t access, uint8_t gran)
{
    gdt_entries[num].base_low    = (base & 0xFFFF);
    gdt_entries[num].base_middle = (base >> 16) & 0xFF;
    gdt_entries[num].base_high   = (base >> 24) & 0xFF;

    gdt_entries[num].limit_low   = (limit & 0xFFFF);
    gdt_entries[num].granularity = (limit >> 16) & 0x0F;

    gdt_entries[num].granularity |= gran & 0xF0;
    gdt_entries[num].access      = access;
}   

void gdt_init()
{
    gdt_ptr.limit = (sizeof(gdt_entry_t) * 6) - 1; // <-- CHANGED
    gdt_ptr.base  = (uint32_t)&gdt_entries;

    // Kernel Code/Data segments (indices 1 and 2)
    gdt_set_gate(0, 0, 0, 0, 0);                
    gdt_set_gate(1, 0, 0xFFFFFFFF, 0x9A, 0xCF); // Kernel Code (Ring 0)
    gdt_set_gate(2, 0, 0xFFFFFFFF, 0x92, 0xCF); // Kernel Data (Ring 0)
    
    // --- ADD THESE THREE NEW GATES ---
    
    // TSS Segment (index 3)
    // 0x89 = Present, Executable, Accessed
    // 0x40 = Granularity (bytes), Limit (first 16 bits)
    gdt_set_gate(3, (uint32_t)&tss, sizeof(tss_entry_t), 0x89, 0x40); 
    
    // User Code Segment (index 4)
    // 0xFA = Present, Ring 3, Code, Executable, Read/Write
    gdt_set_gate(4, 0, 0xFFFFFFFF, 0xFA, 0xCF); // User Code (Ring 3)
    
    // User Data Segment (index 5)
    // 0xF2 = Present, Ring 3, Data, Read/Write
    gdt_set_gate(5, 0, 0xFFFFFFFF, 0xF2, 0xCF); // User Data (Ring 3)

    // --- END OF NEW GATES ---

    gdt_flush((uint32_t)&gdt_ptr);
}