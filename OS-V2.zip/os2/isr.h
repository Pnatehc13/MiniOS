#ifndef ISR_H
#define ISR_H

#include "types.h"

// This is the stack frame pushed by the 'pusha' instruction.
// It contains all the general-purpose registers.
typedef struct {
    uint32_t ds, es, fs, gs;
    uint32_t edi, esi, ebp, esp, ebx, edx, ecx, eax;
} registers_t;

// This is the stack frame pushed by our assembly stubs.
// It contains the interrupt number and the error code (or 0).
typedef struct {
    uint32_t int_no;
    uint32_t err_code;
} int_stack_frame_t;

// Our main C-level handler now takes two arguments:
// 1. A pointer to the saved registers.
// 2. A pointer to the interrupt/error code frame.
void isr_handler_c(registers_t* regs, int_stack_frame_t* stack);

// --- Your Helper Functions (unchanged) ---
void *memset(void *dest, int val, size_t len);
void *memcpy(void *dest, const void *src, size_t n);
int strcmp(const char* s1, const char* s2);
int atoi(const char* str);
void int_to_hex_str(uint32_t n, char* buffer);

#endif