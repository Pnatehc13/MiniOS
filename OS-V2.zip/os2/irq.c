#include "types.h"
#include "irq.h"
#include "terminal.h"
#include "isr.h"

#define MAX_IRQS 256
void (*interrupt_handlers[MAX_IRQS])(registers_t*); // This array stays the same

// Register a handler
void register_interrupt_handler(uint8_t n, void (*handler)(registers_t*)) {
    interrupt_handlers[n] = handler;
}

// I/O port functions
static inline void outb(uint16_t port, uint8_t value) {
    asm volatile ("outb %0, %1" : : "a"(value), "Nd"(port));
}
static inline uint8_t inb(uint16_t port) {
    uint8_t ret;
    asm volatile ("inb %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

// --- PIC Remapping (Unchanged) ---
#define PIC1            0x20
#define PIC2            0xA0
#define PIC1_COMMAND    PIC1
#define PIC1_DATA       (PIC1 + 1)
#define PIC2_COMMAND    PIC2
#define PIC2_DATA       (PIC2 + 1)

#define ICW1_ICW4       0x01
#define ICW1_INIT       0x10
#define ICW4_8086       0x01

void pic_remap(void)
{
    // Zero the handler table
    memset(&interrupt_handlers, 0, sizeof(void*) * MAX_IRQS);

    // Start initialization sequence
    outb(PIC1_COMMAND, ICW1_INIT | ICW1_ICW4);
    outb(PIC2_COMMAND, ICW1_INIT | ICW1_ICW4);

    // Set vector offsets
    outb(PIC1_DATA, 0x20); // Master PIC offset = 0x20 (32)
    outb(PIC2_DATA, 0x28); // Slave PIC offset  = 0x28 (40)

    // Tell Master PIC about Slave at IRQ2
    outb(PIC1_DATA, 4);
    // Tell Slave PIC its cascade identity
    outb(PIC2_DATA, 2);

    // Set environment info
    outb(PIC1_DATA, ICW4_8086);
    outb(PIC2_DATA, ICW4_8086);

    // Mask all interrupts
    outb(PIC1_DATA, 0xFF);
    outb(PIC2_DATA, 0xFF);
}

// --- Main C-level IRQ Handler ---
// This is the new function signature
void irq_handler_c(registers_t* regs, int_stack_frame_t* stack) {
    
    // Get the interrupt number from the 'stack' arg
    uint32_t int_no = stack->int_no;

    // Call user handler if installed
    if (interrupt_handlers[int_no]) {
        interrupt_handlers[int_no](regs);
    }

    // Send EOI (End of Interrupt)
    if (int_no >= 40) // If it was a slave interrupt (40-47)
        outb(0xA0, 0x20); // Send EOI to slave
    
    outb(0x20, 0x20);     // Send EOI to master
}