// c/keyboard.c
#include "keyboard.h"
#include "irq.h"
#include "terminal.h"
#include "ports.h"
#include "shell.h"
// --- STATE VARIABLES ---
static bool is_lshift_pressed = false;
static bool is_rshift_pressed = false;
static bool is_escape_code = false; // <-- NEW

// --- SCANCODE MAPS ---
// (scancode_map and scancode_map_shifted are unchanged)
const char scancode_map[128] = {
    0,  27, '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', '\b',
    '\t', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\n',
    0, 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'', '`', 0,
    '\\', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', 0, '*', 0,
    ' ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};
const char scancode_map_shifted[128] = {
    0,  27, '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', '\b',
    '\t', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '{', '}', '\n',
    0, 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ':', '"', '~', 0,
    '|', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', '<', '>', '?', 0, '*', 0,
    ' ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};


void keyboard_isr_c(registers_t* regs) {
    // 1. Read the scancode
    uint8_t scancode = inb(0x60);
    
    // --- 2. Check for 0xE0 escape code ---
    if (scancode == 0xE0) {
        is_escape_code = true;
        return;
    }

    // --- 3. Check if this is an escaped key ---
    if (is_escape_code) {
        is_escape_code = false; // Consume the escape code
        switch (scancode) {
            case 0x48: terminal_move_cursor_up(); break;
            case 0x50: terminal_move_cursor_down(); break;
            case 0x4B: terminal_move_cursor_left(); break;
            case 0x4D: terminal_move_cursor_right(); break;
        }
        return; // We're done
    }

    // --- 4. Handle normal keys (Shift, etc.) ---
    switch (scancode) {
        case 0x2A: // Left Shift PRESS
            is_lshift_pressed = true;
            return;
        case 0xAA: // Left Shift RELEASE
            is_lshift_pressed = false;
            return;
        case 0x36: // Right Shift PRESS
            is_rshift_pressed = true;
            return;
        case 0xB6: // Right Shift RELEASE
            is_rshift_pressed = false;
            return;
    }

    // --- 5. Handle printable keys ---
    if (scancode < 0x80) { // Key PRESS

        bool shift_is_held = is_lshift_pressed || is_rshift_pressed;

        char c;
        if (shift_is_held) {
            c = scancode_map_shifted[scancode];
        } else {
            c = scancode_map[scancode];
        }

        // --- THIS IS THE CHANGE ---
        if (c != 0) {
            // Instead of printing, send the key to the shell
            shell_handle_key(c);
        }
        // --- END OF CHANGE ---
    }
}