#include "tss.h"
#include "gdt.h" // For DATA_SEGMENT_SELECTOR
#include "isr.h" // For memset

// Our one and only TSS
tss_entry_t tss;

// Import the stack top from asm/boot.s
extern uint32_t stack_top; 

void init_tss(void) {
    // 1. Zero out the TSS
    memset(&tss, 0, sizeof(tss_entry_t));

    // 2. Set tss.ss0 (kernel data segment)
    //    This is the segment the CPU will switch to when an
    //    interrupt happens in user-mode.
    tss.ss0 = DATA_SEGMENT_SELECTOR; // 0x10

    // 3. Set tss.esp0 (kernel stack top)
    //    This is the STACK POINTER the CPU will use
    //    when it switches to the kernel stack.
    tss.esp0 = (uint32_t)&stack_top;

    // 4. Call tss_flush()
    //    (We will write this in asm/tss.s next)
    tss_flush();
}