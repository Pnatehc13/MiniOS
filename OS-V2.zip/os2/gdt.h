#ifndef __GDT_H
#define __GDT_H
#include <stdint.h>
#include "types.h"
#define CODE_SEGMENT_SELECTOR 0x08  // Index 1 in GDT
#define DATA_SEGMENT_SELECTOR 0x10  // Index 2 in GDT
struct gdt_entry_struct {
    uint16_t limit_low;           
    uint16_t base_low;            
    uint8_t  base_middle;         
    uint8_t  access;              
    uint8_t  granularity;         
    uint8_t  base_high;           
} __attribute__((packed));

struct gdt_ptr_struct {
    uint16_t limit;               
    uint32_t base;                
} __attribute__((packed));  


typedef struct gdt_entry_struct gdt_entry_t;
typedef struct gdt_ptr_struct gdt_ptr_t;

void gdt_init();
extern void gdt_flush(uint32_t);



#endif
