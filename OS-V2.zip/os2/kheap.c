#include "kheap.h"
#include "types.h"
#include "isr.h" // For memset
#include "paging.h" // For map_page and unmap_page  
#include "terminal.h" // For page_director
// This is the symbol from our linker script
extern uint32_t _kernel_end;

static uint8_t* memory_bitmap = 0;
static uint32_t total_pages = 4096; // 16MB
static uint32_t bitmap_size = 512;  // 4096 pages / 8 bits per byte

// --- Helper Functions ---

// Sets a bit in the bitmap (1 = used)
void set_page_used(uint32_t page_index) {
    // Check to prevent buffer overflow
    if (page_index >= total_pages) return; 
    
    uint32_t byte_index = page_index / 8;
    uint8_t bit_index = page_index % 8;
    memory_bitmap[byte_index] |= (1 << bit_index);
}

// Clears a bit in the bitmap (0 = free)
void set_page_free(uint32_t page_index) {
    // Check to prevent buffer overflow
    if (page_index >= total_pages) return;

    uint32_t byte_index = page_index / 8;
    uint8_t bit_index = page_index % 8;
    memory_bitmap[byte_index] &= ~(1 << bit_index);
}

// Checks if a page is used
bool is_page_used(uint32_t page_index) {
    if (page_index >= total_pages) return true; // Treat out-of-bounds as "used"
    
    uint32_t byte_index = page_index / 8;
    uint8_t bit_index = page_index % 8;
    return (memory_bitmap[byte_index] & (1 << bit_index)) != 0;
}

// --- Main Init Function ---

void init_kheap(void) {
    // 1. Place the bitmap right after the kernel's end address
    memory_bitmap = (uint8_t*)&_kernel_end;

    // 2. Calculate total memory used by (kernel + bitmap itself)
    uint32_t total_used_memory = (uint32_t)&_kernel_end + bitmap_size;
    
    // 3. Round *up* to the nearest page
    // This fixes BOTH bugs at once!
    uint32_t total_used_pages = (total_used_memory + 4095) / 4096;

    // 4. Clear the *entire* bitmap first (all 0 = free)
    memset(memory_bitmap, 0, bitmap_size);

    // 5. Mark all pages (low mem, kernel, bitmap) as USED
    for (uint32_t i = 0; i < total_used_pages; i++) {
        set_page_used(i);
    }
}

// We need a "next free" virtual address.
// We'll start our heap at 3GB (0xC0000000), a standard spot.
static uint32_t next_free_virtual_addr = 0xC0000000;

// RENAMED: This is your old kmalloc_page.
// It finds and reserves a PHYSICAL page.
uint32_t alloc_phys_page(void) {
    for (uint32_t i = 0; i < total_pages; i++) {
        if (!is_page_used(i)) {
            set_page_used(i);
            return i * 4096; // Return the physical ADDRESS
        }
    }
    return 0; // Out of memory
}

// RENAMED: This is your old kfree_page.
// It frees a PHYSICAL page.
void free_phys_page(uint32_t phys_addr) {
    uint32_t page_index = phys_addr / 4096;
    set_page_free(page_index);
}

// --- PUBLIC FUNCTIONS ---

// This is the REAL kmalloc (for 4KB pages)
void* kmalloc_page(void) {
    // 1. Get a free PHYSICAL page
    uint32_t phys_addr = alloc_phys_page();
    if (phys_addr == 0) {
        terminal_writestring("kmalloc: Out of physical memory!\n");
        return NULL;
    }
    
    // 2. Get a VIRTUAL address
    uint32_t virt_addr = next_free_virtual_addr;
    next_free_virtual_addr += 4096; // Increment for next time
    
    // 3. Map it!
    //    Flags 0x3 = Present, Read/Write
    map_page(phys_addr, virt_addr, 0x3);
    
    // 4. Return the VIRTUAL pointer
    return (void*)virt_addr; // <-- THIS IS THE FIX
}

// This is the REAL kfree
void kfree_page(void* ptr) {
    uint32_t virt_addr = (uint32_t)ptr;
    
    // 1. Find the physical address (This is tricky! We have to
    //    read our own page tables.)
    uint32_t dir_index = virt_addr >> 22;
    uint32_t table_index = (virt_addr >> 12) & 0x3FF;

    if (page_directory[dir_index] & 0x1) {
        uint32_t* page_table = (uint32_t*)(page_directory[dir_index] & 0xFFFFF000);
        
        // 2. Get the physical address from the table
        uint32_t phys_addr = page_table[table_index] & 0xFFFFF000;
        
        // 3. Free the PHYSICAL page
        free_phys_page(phys_addr);
        
        // 4. Unmap the VIRTUAL page
        unmap_page(virt_addr);
    }
}