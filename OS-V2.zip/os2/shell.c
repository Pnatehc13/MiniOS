#include "shell.h"
#include "terminal.h"
#include "isr.h"
#include "types.h"
#include "timer.h" // For sleep_s
#include "kheap.h" // For kmalloc_page
#include "isr.h" // For int_to_hex_str
#include "multitasking.h" // For jump_to_user_mode
#define MAX_CMD_LEN 128

static char cmd_buffer[MAX_CMD_LEN];
static int cmd_index = 0;
static bool command_ready = false; // <-- NEW FLAG

// Helper function to print the prompt
void shell_print_prompt(void) {
    terminal_writestring("> ");
}

// NEW: Helper function to parse the command
int shell_parse_command(char* buffer, char** argv) {
    int argc = 0;
    char* current_arg = buffer;

    while (*buffer && argc < MAX_CMD_LEN / 2) {
        if (*buffer == ' ') {
            *buffer = '\0'; // Replace space
            argv[argc] = current_arg;
            argc++;
            
            while (*(buffer + 1) == ' ') buffer++; // Skip multiple spaces
            current_arg = buffer + 1;
        }
        buffer++;
    }
    
    if (*current_arg) {
        argv[argc] = current_arg;
        argc++;
    }
    return argc;
}

// RENAMED: This is your old shell_run_command
// This is now called by kernel.c, not the interrupt
void shell_run_command_from_buffer(void) {
    command_ready = false; // We are handling it
    if (cmd_index == 0) {
        return; // Empty command
    }

    char* argv[MAX_CMD_LEN / 2];
    int argc = shell_parse_command(cmd_buffer, argv);

    if (argc == 0) {
        return;
    }

    // --- Your IF/ELSE chain is unchanged ---
    if (strcmp(argv[0], "clear") == 0) {
        terminal_initialize();
    } else if (strcmp(argv[0], "help") == 0) {
        terminal_writestring("Simple OS Shell\nCommands:\n  clear - Clear the screen\n  help  - Show this message\n  echo  - Print arguments\n  version - Show version\n  sleep - Pause the shell\n");
    } else if (strcmp(argv[0], "version") == 0) {
        terminal_writestring("Simple OS Shell version 0.1\n");
    } else if (strcmp(argv[0], "echo") == 0) {
        for (int i = 1; i < argc; i++) {
            terminal_writestring(argv[i]);
            terminal_writestring(" ");
        }
        terminal_writestring("\n");
    } else if (strcmp(argv[0], "sleep") == 0) {
        if (argc < 2) {
            terminal_writestring("Usage: sleep <seconds>\n");
        } else {
            int seconds = atoi(argv[1]);
            terminal_writestring("Sleeping for ");
            terminal_writestring(argv[1]);
            terminal_writestring(" seconds...\n");
            
            sleep_s(seconds);
            
            terminal_writestring("Awake!\n");
        }
    } 
    else if (strcmp(argv[0], "test_crash") == 0) {
        terminal_writestring("Attempting to write to read-only memory...\n");
        // Address 0x200000 is where our kernel starts
        // and is now marked as Read-Only.
        int* bad_ptr = (int*)0x200000;
        
        // This line *will* cause a Page Fault (Exception 14)
        *bad_ptr = 123; 
        
        // This line should never be reached:
        terminal_writestring("...Write successful? (This shouldn't happen!)\n");
    // --- END NEW BLOCK ---

    }
    else if (strcmp(argv[0], "test_heap") == 0) {
        terminal_writestring("Allocating one page...\n");
        void* ptr = kmalloc_page();
        
        if (ptr == NULL) {
            terminal_writestring("  Failed! Out of memory.\n");
        } else {
            // Use our hex print function to show the address
            char addr_buf[11];
            int_to_hex_str((uint32_t)ptr, addr_buf);
            terminal_writestring("  Got page at virtual address: ");
            terminal_writestring(addr_buf);
            terminal_writestring("\n");

            // Now, try to write to it
            terminal_writestring("  Writing '12345' to address...\n");
            int* test_ptr = (int*)ptr;
            *test_ptr = 12345;

            // Read it back to confirm
            if (*test_ptr == 12345) {
                terminal_writestring("  Write successful! Data read back.\n");
            } else {
                terminal_writestring("  Write FAILED!\n");
            }
            
            // Free the page
            terminal_writestring("  Freeing page...\n");
            kfree_page(ptr);
            terminal_writestring("  Done.\n");
        }
    // --- END NEW BLOCK ---

    }
    else if (strcmp(argv[0], "test_usermode") == 0) {
        terminal_writestring("Attempting to jump to user mode...\n");
        terminal_writestring("If this works, you will see 'Exception: 13'.\n");
        jump_to_user_mode();
        
        // This line should never be reached!
        terminal_writestring("...Failed to jump?\n");
    // --- END NEW BLOCK ---

    }
    else {
        terminal_writestring("Unknown command: ");
        terminal_writestring(argv[0]);
        terminal_writestring("\n");
    }
    
    // --- ADD THIS AT THE END ---
    // After running, reset the buffer for the next command
    memset(cmd_buffer, 0, MAX_CMD_LEN);
    cmd_index = 0;
}

// UPDATED: This is called by the KEYBOARD INTERRUPT
void shell_handle_key(char c) {
    if (c == '\b') { // Backspace
        if (cmd_index > 0) {
            cmd_index--;
            cmd_buffer[cmd_index] = '\0';
            terminal_backspace();
        }
    } else if (c == '\n') { // Enter
        terminal_putchar('\n');
        
        // --- CHANGED ---
        // Don't run the command, just set the flag
        command_ready = true;
        // --- END ---
        
    } else if (cmd_index < MAX_CMD_LEN - 1) { // Printable char
        cmd_buffer[cmd_index] = c;
        cmd_index++;
        terminal_putchar(c); // Echo to screen
    }
}

// UPDATED: Initialize the shell
void shell_init(void) {
    memset(cmd_buffer, 0, MAX_CMD_LEN);
    cmd_index = 0;
    command_ready = false; // Ensure flag is off
    shell_print_prompt();
}

// NEW: Helper for kernel.c to check the flag
bool shell_is_command_ready(void) {
    return command_ready;
}