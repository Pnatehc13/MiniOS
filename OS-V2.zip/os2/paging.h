#ifndef PAGING_H
#define PAGING_H

#include "types.h"
#include "isr.h"

// A Page Fault error code, pushed by the CPU for Exception 14
// We can parse this to find out what went wrong.
typedef struct {
    uint32_t present   : 1; // Page was not present
    uint32_t rw        : 1; // 0 = read, 1 = write
    uint32_t user      : 1; // 0 = kernel, 1 = user
    uint32_t reserved  : 1; // CPU reserved bit
    uint32_t fetch     : 1; // 0 = data, 1 = instruction fetch
    uint32_t reserved2 : 27;
} page_fault_code_t;

extern uint32_t page_directory[1024];

// --- Functions ---

// Sets up the page directory, page tables, and enables paging.
void init_paging(void);

// This will be our new Exception 14 handler
void page_fault_handler(registers_t* regs, int_stack_frame_t* stack);

// Maps a physical address to a virtual address in the page directory
void map_page(uint32_t phys_addr, uint32_t virt_addr, uint32_t flags);

// Unmaps a virtual address
void unmap_page(uint32_t virt_addr);


#endif